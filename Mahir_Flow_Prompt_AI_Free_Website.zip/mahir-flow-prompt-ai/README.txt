MAHIR FLOW PROMPT AI — FREE WEBSITE STARTER

Included:
- index.html: responsive, working prompt generator
- No paid API, login, or server required for the demo
- Works locally in a modern browser and can be published on a free static hosting service

To test on Android:
1. Extract the ZIP.
2. Open index.html in a browser or upload it to a free static hosting provider.

To publish free with GitHub Pages:
1. Sign in or create an account at github.com.
2. Create a public repository named mahir-flow-prompt-ai.
3. Upload index.html to the repository root.
4. Open Settings > Pages, choose Deploy from a branch, select main and /(root), then Save.
5. Wait for GitHub Pages to publish and use the URL shown in Settings > Pages.

Income:
This starter does NOT automatically earn money. It has no ad network, payment system, AI API, or user accounts. First publish it, share it, and improve it with original useful content. Advertising requires applying to a network and meeting its current requirements; approval and income are not guaranteed. Do not claim it is an official Google product.
